//Pour voir comment le site web final doit fonctionner, exécutez "node solution.js".
//Assurez-vous d'avoir installé toutes les dépendances avec "npm i".
//Le mot de passe est ILoveProgramming
