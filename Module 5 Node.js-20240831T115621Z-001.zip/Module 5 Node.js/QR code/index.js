/* 
1. Utilisez le package Inquirer npm pour obtenir le lien de l'utilisateur.
2. Utilisez le package qr-image npm pour transformer l'URL saisi par l'utilisateur en une image de code QR.
3. Créez un fichier txt pour enregistrer le lien saisi par l'utilisateur à l'aide du module de node fs natif.
*/
