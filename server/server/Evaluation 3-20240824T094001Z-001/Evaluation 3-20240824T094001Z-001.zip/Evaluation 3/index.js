const images = [
    { src: 'images/photo1.jpg', caption: 'Légende de la Photo 1' },
    { src: 'images/photo2.jpg', caption: 'Légende de la Photo 2' },
    { src: 'images/photo3.jpg', caption: 'Légende de la Photo 3' },
    { src: 'images/photo4.jpg', caption: 'Légende de la Photo 4' },
    { src: 'images/photo5.jpg', caption: 'Légende de la Photo 5' }
];
